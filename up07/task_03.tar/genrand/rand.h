#ifndef RAND_H
	#define RAND_H 1
	extern int rand_range(int low, int high);
#endif