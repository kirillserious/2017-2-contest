#include <stdlib.h>
#include <stdio.h>
#include "rand.h"

int
rand_range (int low, int high)
{
    return (int)((double)rand() * (high-low) / (RAND_MAX+1.0)) + low;
}